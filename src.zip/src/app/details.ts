export class details {
    name: string;
    rating: number;
    id: string;
    formatted_address: string;
}
